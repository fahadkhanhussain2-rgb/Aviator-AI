package com.aviatorai.analyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.sqrt

data class Analysis(
    val count: Int,
    val under15: Double,
    val under20: Double,
    val over2: Double,
    val over5: Double,
    val mean: Double,
    val median: Double,
    val std: Double,
    val streak: Int,
    val signal: String,
    val confidence: Int
)

class AnalyzerViewModel : ViewModel() {
    var input by mutableStateOf(
        "1.12,1.43,2.10,1.07,3.42,1.22,1.01,2.75,1.65,4.20,1.18,1.36,2.02,1.09,5.10"
    )
    var analysis by mutableStateOf<Analysis?>(null)
    var error by mutableStateOf("")

    fun analyze() {
        val values = input.split(",", "\n", " ", "\t")
            .mapNotNull { it.trim().removeSuffix("x").toDoubleOrNull() }
            .filter { it >= 1.0 }

        if (values.size < 5) {
            error = "Enter at least 5 valid multipliers."
            analysis = null
            return
        }

        val sorted = values.sorted()
        val mean = values.average()
        val median = if (sorted.size % 2 == 0)
            (sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2.0
        else sorted[sorted.size / 2]

        val variance = values.map { (it - mean) * (it - mean) }.average()
        val std = sqrt(variance)
        val under15 = values.count { it < 1.5 }.toDouble() / values.size
        val under20 = values.count { it < 2.0 }.toDouble() / values.size
        val over2 = values.count { it >= 2.0 }.toDouble() / values.size
        val over5 = values.count { it >= 5.0 }.toDouble() / values.size

        var streak = 0
        for (v in values.asReversed()) {
            if (v < 1.5) streak++ else break
        }

        // Conservative research signal only. It is deliberately NOT a betting instruction.
        val signal = when {
            values.size < 30 -> "INSUFFICIENT DATA"
            under15 >= 0.70 -> "HIGH RISK / NO BET"
            under20 >= 0.75 -> "HIGH RISK / NO BET"
            else -> "MONITOR"
        }

        val confidence = when {
            values.size < 30 -> 25
            values.size < 100 -> 50
            else -> 70
        }

        analysis = Analysis(
            values.size, under15, under20, over2, over5,
            mean, median, std, streak, signal, confidence
        )
        error = ""
    }
}

@Composable
fun Metric(label: String, value: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontWeight = FontWeight.Medium)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: AnalyzerViewModel) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF62FF55),
            secondary = Color(0xFFFFB300),
            background = Color(0xFF090B0A),
            surface = Color(0xFF141816)
        )
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("Aviator AI Analyzer", fontWeight = FontWeight.Bold) }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(
                                "Research / Paper Mode",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Paste historical crash multipliers below. This app performs statistical analysis only; it does not place or automate real-money bets."
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = vm.input,
                        onValueChange = { vm.input = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                        label = { Text("Historical multipliers") },
                        placeholder = { Text("1.12, 1.43, 2.10, 1.07...") }
                    )
                }

                item {
                    Button(
                        onClick = { vm.analyze() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("RUN ANALYSIS")
                    }
                }

                if (vm.error.isNotEmpty()) {
                    item { Text(vm.error, color = MaterialTheme.colorScheme.error) }
                }

                vm.analysis?.let { a ->
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (a.signal.startsWith("HIGH"))
                                    Color(0xFF351616) else Color(0xFF122818)
                            ),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("RESEARCH SIGNAL", style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    a.signal,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Black
                                )
                                Text("Confidence: ${a.confidence}%")
                            }
                        }
                    }

                    item { Metric("Rounds analysed", a.count.toString()) }
                    item { Metric("< 1.50x rate", "${"%.1f".format(a.under15 * 100)}%") }
                    item { Metric("< 2.00x rate", "${"%.1f".format(a.under20 * 100)}%") }
                    item { Metric(">= 2.00x rate", "${"%.1f".format(a.over2 * 100)}%") }
                    item { Metric(">= 5.00x rate", "${"%.1f".format(a.over5 * 100)}%") }
                    item { Metric("Mean", "%.2fx".format(a.mean)) }
                    item { Metric("Median", "%.2fx".format(a.median)) }
                    item { Metric("Std deviation", "%.2f".format(a.std)) }
                    item { Metric("Current <1.5x streak", a.streak.toString()) }

                    item {
                        Text(
                            "Important: streaks and historical percentages do not prove what the next round will do. Use this app for research and simulation, not guaranteed-profit decisions.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AnalyzerViewModel = viewModel()
            App(vm)
        }
    }
}
