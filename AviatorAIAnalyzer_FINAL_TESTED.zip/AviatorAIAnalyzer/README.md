# Aviator AI Analyzer

Android research/paper-mode app for analysing historical Aviator-style crash multipliers.

## What it does

- Accepts historical multipliers
- Calculates <1.5x, <2x, >=2x and >=5x rates
- Calculates mean, median and standard deviation
- Detects the current low-multiplier streak
- Produces a conservative research signal
- Builds automatically with GitHub Actions

## What it does NOT do

This project does not log into a casino account, place bets, cash out, bypass platform controls, or automate real-money gambling.

Historical streaks do not establish a reliable prediction of the next independent round. The app therefore labels its output as a research signal.

## Build on GitHub

1. Create a new GitHub repository.
2. Upload all files from this project, preserving folders.
3. Commit to `main`.
4. Open the **Actions** tab.
5. Run **Build Android APK** or push another commit.
6. Download the generated `AviatorAIAnalyzer-debug` artifact.

## Local build

Requires JDK 17 and Android SDK 37.

The GitHub workflow generates the Gradle wrapper automatically and runs:

`./gradlew assembleDebug`

## Next development phase

Possible research additions:

- CSV import/export
- local Room database
- round history chart
- walk-forward backtesting
- calibration metrics
- Monte Carlo simulation
- provably-fair verification when official verification inputs are available
- paper bankroll simulator
